<template lang="pug">
.curso-main-container.introduccion
  BannerInterno(subTitulo="Introducción")
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.mb-5
    .row.mb-5 
      .col-lg-8.mb-3.mb-lg-0 
        p(data-aos="fade-down") En un entorno laboral caracterizado por su dinamismo y constante evolución, la seguridad vial en el ámbito laboral se ha convertido en un aspecto fundamental para garantizar la integridad física de los empleados y la continuidad de las operaciones. La complejidad que rodea esta temática, requiere un enfoque integral que permita a las organizaciones adoptar medidas efectivas y responsables para reducir los riesgos asociados a la movilidad laboral. En este contexto, la presente unidad de formación, titulada "Fundamentos de la seguridad vial laboral", se presenta como una herramienta esencial para capacitar a los profesionales en la comprensión, gestión y promoción de prácticas seguras, en el desplazamiento dentro del entorno laboral.
        .bg-color-1.p-4(data-aos="fade-up") 
          p(data-aos="fade-down").mb-0 Este programa tiene como finalidad dotar a los participantes de conocimientos y habilidades básicas sobre los principios y conceptos esenciales en seguridad vial laboral. A través de metodologías participativas y dinámicas, se busca fomentar un ambiente de aprendizaje colaborativo, que facilite la reflexión y aplicación práctica de los conocimientos adquiridos, permitiendo abordar los desafíos de la seguridad vial desde una perspectiva integral y preventiva.    
      .col-lg-4
        figure
          img.img-a.img-t(src="@/assets/curso/temas/1.png", data-aos="zoom-in")            


    .bg-color-2.p-4.mb-4(data-aos="fade-left")
      .row.align-items-start
        .col-lg-auto
          img.img-a.img-t(src="@/assets/curso/temas/2.svg")
        .col-lg
          p.mb-0 La unidad se estructura en cuatro módulos principales: el primero, "Definiciones y conceptos claves en seguridad vial laboral", proporciona un entendimiento sólido sobre los términos y principios fundamentales que rigen la seguridad en la movilidad laboral; el segundo, "Estadísticas y panorama actual de la accidentalidad vial laboral", presenta datos relevantes y análisis sobre la situación actual, resaltando la importancia de acciones preventivas; el tercer módulo, "Marco Legal y Normativo de la Seguridad Vial en Colombia", explica las leyes, reglamentos y obligaciones que rigen la seguridad vial en el país, promoviendo el cumplimiento normativo; y el cuarto, "Estándares internacionales y guías de buenas prácticas en seguridad vial", introduce las recomendaciones y estándares internacionales que sirven como referencia para fortalecer las políticas y programas en esta materia. 
</template>
