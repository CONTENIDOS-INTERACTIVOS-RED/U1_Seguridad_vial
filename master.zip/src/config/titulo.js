module.exports = 'Fundamentos de la seguridad vial laboral'
